

<?php $__env->startSection('subhead'); ?>
    <title>Create Data With API</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subcontent'); ?>
    <div class="intro-y flex items-center mt-8">
        <h2 class="text-lg font-medium mr-auto">Form Tambah Data Buku</h2>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 lg:col-span-6">
        <?php if(count($errors) > 0): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-warning"><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            <!-- BEGIN: Form Layout -->
            <form action="<?php echo e(route('dashboardstore')); ?>" method='POST'>
            <?php echo csrf_field(); ?>
            <div class="intro-y box p-5">
                <div>
                    <label for="crud-form-1" class="form-label">Nama Buku</label>
                    <input id="nama-buku" type="text" class="form-control w-full" name="nama-buku" >
                </div>
                <div class="mt-3">
                <div>
                    <label for="crud-form-1" class="form-label">Harga Buku</label>
                    <input id="harga-buku" type="text" class="form-control w-full" name="harga-buku" >
                </div>
                <div class="mt-3">
                <div>
                    <label for="crud-form-1" class="form-label">Deskripsi Buku</label>
                    <input id="deskripsi-buku" type="text" class="form-control w-full" name="deskripsi-buku" >
                </div>
                <div class="mt-3">
                <div class="text-right mt-5">
                    <button type="reset" class="btn btn-outline-secondary w-24 mr-1">Cancel</button>
                    <button type="submit" class="btn btn-primary w-24">Save</button>
                </div>
            </div>
            </form>
            <!-- END: Form Layout -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(mix('dist/js/ckeditor-classic.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Rekayasa Web\prebuildlaravel\resources\views/Dashboard/create.blade.php ENDPATH**/ ?>