

<?php $__env->startSection('subhead'); ?>
    <title>Dashboard - Rekayasa Web</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subcontent'); ?>

<h2 class="intro-y text-lg font-medium mt-10">List Data Buku</h2>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <a href="<?php echo e(route('dashboardcreate')); ?>"><button class="btn btn-primary shadow-md mr-2">
                Tambah Buku</button></a>
            <div class="hidden md:block mx-auto text-slate-500">Showing list data entries</div>
            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
            </div>
        </div>
                <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <table class="table table-report -mt-2">
                <thead>
                    <tr>
                        <th class="whitespace-nowrap">ID</th>
                        <th class="whitespace-nowrap">Nama Buku</th>
                        <th class="text-center whitespace-nowrap">Harga Buku</th>
                        <th class="text-center whitespace-nowrap">Deskripsi</th>
                        <th class="text-center whitespace-nowrap">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="intro-x">
                            <td class="w-40">
                                <div class="flex">
                                    <div class="w-10 h-10 image-fit zoom-in">
                                    <?php echo e($value['id']); ?> 
                                    </div>
                                </div>
                            </td>
                            <td>
                               
                                <div class="text-slate-500"><?php echo e($value['nama_buku']); ?></div>
                            </td>
                            <td class="text-center"><?php echo e($value['harga']); ?></td>
                            <td class="">
                                <div class="flex items-center justify-center <?php echo e($value['deskripsi']); ?>">
                                     <?php echo e($value['deskripsi']); ?>

                                </div>
                            </td>
                            <td class="table-report__action w-56">
                                <div class="flex justify-center items-center">
                                    <a class="flex items-center mr-3" href="javascript:;">
                                        <i data-feather="check-square" class="w-4 h-4 mr-1"></i> Edit
                                    </a>
                                    <a class="flex items-center text-danger" href="javascript:;" 
                                    data-tw-toggle="modal" data-tw-target="#delete-confirmation-modal">
                                        <i data-feather="trash-2" class="w-4 h-4 mr-1"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Rekayasa Web\prebuildlaravel\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>